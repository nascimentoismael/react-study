const NotFound = () => {
    return <h3>Página não encontrada!</h3>;
};

export default NotFound;
