const ConsultarAluno = () => {
    return <h3>Página lista exercícios!</h3>;
};

export default ConsultarAluno;
