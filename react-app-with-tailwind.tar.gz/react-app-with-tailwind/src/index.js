import React from 'react';
import { createRoot } from 'react-dom/client';
import { BrowserRouter, Routes, Route } from 'react-router-dom';
import NotFound from './NotFound';
import Home from './Home';
import Layout from './Layout';
import ListaAlunos from './ListaAlunos';
import ConsultarAluno from './ConsultarAluno';
import ListaExercicios from './ListaExercicios';
import Fichas from './Fichas';

const App = () => {
  return (
      <BrowserRouter>
          <Routes>
              <Route path='/' element={<Layout />}>
                  {/* <Route index element={<Home />} /> */}
                  <Route path='/ListaAlunos' element={<ListaAlunos />} />
                  <Route path='/ListaExercicios' element={<ListaExercicios />} />
                  <Route path='/Fichas' element={<Fichas />} />
                  <Route path='/ListaAlunos/consultar/:id' exact element={<ConsultarAluno />} />
                  <Route path='/*' element={<NotFound />} />
              </Route>
          </Routes>
      </BrowserRouter>
  );
};

const root = createRoot(document.querySelector("#root"));

root.render(<App />);